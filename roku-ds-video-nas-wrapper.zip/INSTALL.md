# Roku DS Video NAS Wrapper Install

This wrapper lets the Roku app play Synology Video Station HLS/transcoded streams directly, including AVI files that Video Station can transcode.

## Requirements

- Synology Video Station installed and indexed.
- SSH access with a DSM administrator account that can use `sudo`.
- Python 3 on the NAS at `/usr/bin/python3`.

## Install

On macOS or Linux, unzip this folder, open Terminal, then run:

```sh
cd /path/to/roku-ds-video-nas-wrapper
chmod +x install-videostation-rokuvte-wrapper.sh
./install-videostation-rokuvte-wrapper.sh administrator@10.0.1.80
```

Example:

```sh
./install-videostation-rokuvte-wrapper.sh administrator@10.0.1.80
```

If you use HTTPS, set `NAS_WEB_BASE` for the endpoint check:

```sh
NAS_WEB_BASE=https://10.0.1.80:5001 ./install-videostation-rokuvte-wrapper.sh administrator@10.0.1.80
```

On Windows, use WSL or Git Bash because the installer is a Bash script:

```sh
cd /mnt/c/Users/YOUR_NAME/Downloads/roku-ds-video-nas-wrapper
chmod +x install-videostation-rokuvte-wrapper.sh
./install-videostation-rokuvte-wrapper.sh administrator@10.0.1.80
```

For HTTPS on Windows:

```sh
NAS_WEB_BASE=https://10.0.1.80:5001 ./install-videostation-rokuvte-wrapper.sh administrator@10.0.1.80
```

The installer backs up existing wrapper files under:

```text
/root/rokuvte-wrapper-backup-YYYYMMDD-HHMMSS
```

## Roku App

In the Roku app, enter only your normal DSM connection info:

- NAS address
- DSM port
- HTTP/HTTPS protocol
- Synology username
- Synology password

No extra connection settings are needed.
